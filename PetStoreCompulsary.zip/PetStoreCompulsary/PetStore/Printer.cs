﻿using PetShop.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PetStore
{
	public class Printer
	{


		List<Pet> PetList = new List<Pet>();
		public void AddPetsxDefault()
		{
			PetList.Add(new Pet { ID = 1, Name = "Bruno", Type = "Dog", Birthday = new DateTime(2010, 06, 15), SoldDate = new DateTime(2011, 06, 15), color = "black", Price = 50 });
			PetList.Add(new Pet { ID = 2, Name = "Mars", Type = "Rabbit", Birthday = new DateTime(2014, 06, 15), SoldDate = new DateTime(2015, 06, 15), color = "white", Price = 72 });
			PetList.Add(new Pet { ID = 3, Name = "Dogoo", Type = "Dog", Birthday = new DateTime(2017, 06, 15), SoldDate = new DateTime(2018, 06, 15), color = "grey", Price = 100 });
			PetList.Add(new Pet { ID = 4, Name = "sliter", Type = "Snake", Birthday = new DateTime(2016, 06, 19), SoldDate = new DateTime(2014, 06, 15), color = "black", Price = 1400 });
			PetList.Add(new Pet { ID = 5, Name = "meow", Type = "Cat", Birthday = new DateTime(2012, 07, 15), SoldDate = new DateTime(2016, 06, 15), color = "white with black", Price = 62 });
		}

		public void SwitchMenu()
		{

			{
				Console.WriteLine("PetShop:                     |");
				Console.WriteLine("/////////////////////////////|");
				Console.WriteLine("1: List all animals          |");
				Console.WriteLine("2: Change animal Data        |");
				Console.WriteLine("3: Delete animal             |");
				Console.WriteLine("4: Add new animal            |");
				Console.WriteLine("5: Search for an animal      |");
				Console.WriteLine("6: Sort List by price        |");
				Console.WriteLine("-----------------------------|");

			}

			var selectedMenu = int.Parse(Console.ReadLine());
			switch (selectedMenu)
			{
				case 1: { ListAnimals(); break; }
				case 2: { ChangeAnimal(); break; }
				case 3: { DeleteAnimal(); break; }
				case 4: { AddAnimal(); break; }
				case 5: { SearchAnimal(); break; }
				case 6: { SortList(); break; }
				default: { Console.WriteLine("option is not valid"); break; }
			}

			void SearchAnimal()
			{
				Console.WriteLine("Search by the Animal type (For example dogs,cats,): ");

				var searched = Console.ReadLine();
				var AnimalSearched = PetList.Find(pet => pet.Type == searched);
				if (AnimalSearched != null)
				{
					Console.WriteLine("Animal was found: ");
					Console.WriteLine("ID: {0}, Name: {1}, Type: {2},Birthday: {3}", AnimalSearched.ID, AnimalSearched.Type, AnimalSearched.Name, AnimalSearched.Birthday);
				}
				else Console.WriteLine("Animal was not found");
				SwitchMenu();
			}

			void AddAnimal()
			{
				Console.WriteLine("Adding an Animal:");
				Random rnd = new Random();
				int wild = 0;
				var checkForUniqueID = false;
				while (checkForUniqueID == false)
				{

					wild = rnd.Next(1, 99);
					int counter = 0;
					foreach (var Pet in PetList)
					{
						counter++;
						if (wild != Pet.ID || counter == 99) { checkForUniqueID = true; }
					}


				}

				Console.WriteLine("Enter Animal Id:");
				var newAnimalId = Console.ReadLine();

				Console.WriteLine("Enter Animal Name");
				var newAnimalName = Console.ReadLine();

				Console.WriteLine("Enter Animal type");
				var newAnimalType = Console.ReadLine();

				object riperoni = newAnimalName;
				var newAnimal = new Pet() { ID = wild, Name = newAnimalName, Type = newAnimalId };
				PetList.Add(newAnimal);

				SwitchMenu();
			}
			void DeleteAnimal()
			{
				Console.WriteLine("Write an ID of an Animal you want to Delete:");
				var AnimalID = int.Parse(Console.ReadLine());
				var AnimalDelte = PetList.Find(smth => smth.ID == AnimalID);
				PetList.Remove(AnimalDelte);
				SwitchMenu();

			}

			void ChangeAnimal()
			{
				Console.WriteLine("Enter Animal Id you want to change: ");
				var AnimalID = int.Parse(Console.ReadLine());

				Pet petlist = PetList.Find(smth => smth.ID == AnimalID);
				Console.WriteLine("New Data...wait few seconds:  ");
				var newTitle = Console.ReadLine();
				petlist.Name = newTitle;
				SwitchMenu();
			}

			void ListAnimals()
			{

				Console.WriteLine("Listing Animals: ");
				foreach (var Pet in PetList)
				{
					Console.WriteLine("ID: {0}, Name = {1}, Type: {2}, Birthday = {3}, SoldDate = {4}, color = {5}, Price = {6}", Pet.ID, Pet.Name, Pet.Type, Pet.Birthday, Pet.SoldDate, Pet.color, Pet.Price);
				}
				Console.WriteLine("");
				SwitchMenu();

			}

			void SortList()
			{
				var list = PetList.OrderBy(Pets => Pets.Price);
				foreach (var Pet in list)
				{
					Console.WriteLine("Price = {0}", Pet.Price);
				}
				SwitchMenu();

			}













		}
	}
}

﻿using PetShop.Infrastructure.Data.Repositories;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;


namespace PetStore
{
	 class Program
	{
	    

		static void Main(string[] args)
		{
		
			var printer = new Printer();
			printer.AddPetsxDefault();

			printer.SwitchMenu();
			Console.ReadKey();
		}

	}
}


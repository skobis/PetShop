﻿using System;

namespace PetRepository
{
	public class Class1
	{
	}
}

﻿using PetShop.Core.Entities;
using PetShopCore.DomainService;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PetShop.Infrastructure.Data.Repositories
{
	public class PetRepository
	{

	}
	
}


﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PetShop.Core.Entities
{
	public class Pet
	{
		public int ID { get; set; }
		public string Type { get; set; }
		public string Name { get; set; }
		public DateTime Birthday { get; set; }
		public DateTime Birtday { get; set; }
		public DateTime SoldDate { get; set; }
		public string color { get; set; }
		public double Price{ get; set; }

	}
}
